public class VosTest {
}

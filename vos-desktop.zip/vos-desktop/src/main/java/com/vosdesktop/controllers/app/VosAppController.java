package com.vosdesktop.controllers.app;

import java.util.HashMap;

public class VosAppController {

}

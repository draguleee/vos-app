package com.vosdesktop.controllers.app;

import javax.swing.undo.UndoManager;
import java.io.Serializable;

public class OetpnController implements Serializable {

}

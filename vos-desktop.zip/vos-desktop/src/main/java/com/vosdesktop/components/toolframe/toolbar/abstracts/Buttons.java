package com.vosdesktop.components.toolframe.toolbar.abstracts;

import javax.swing.*;

public abstract class Buttons extends JButton {

    private JButton button;

    public abstract void setButton(JButton button);
}

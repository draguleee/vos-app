package com.vosdesktop.components.toolframe.menubar.abstracts;

import javax.swing.*;

public abstract class Menu extends JMenu {

    private JMenu menu;

    public abstract void setMenu(JMenu menu);
}

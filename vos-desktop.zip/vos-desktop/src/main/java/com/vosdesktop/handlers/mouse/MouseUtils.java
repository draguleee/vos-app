package com.vosdesktop.handlers.mouse;

import java.awt.event.MouseEvent;

public interface MouseUtils {

    boolean isLeftMouse(MouseEvent evt);
}
